#ifndef STM32_FLASH_H_
#define STM32_FLASH_H_

int stm32_flash(const char *device_name, void *data, int len);

#endif
